import { GameApp } from './GameApp'

function App() {
  return <GameApp />
}

export default App
